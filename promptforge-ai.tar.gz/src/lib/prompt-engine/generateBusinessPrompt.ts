import type { GeneratorOptions, IdeaAnalysis } from "@/lib/prompt-engine/types";
import { buildContextBlock } from "@/lib/prompt-engine/templates";

export function generateBusinessPrompt(
  analysis: IdeaAnalysis,
  options: GeneratorOptions,
) {
  return `Role:
You are a senior SaaS product strategist and growth planner.

Context:
${buildContextBlock(options, analysis)}

Business Planning Mission:
Produce a practical business and product plan for this idea.

Must Include:
1. Product positioning and core value proposition
2. Target market and ideal customer profile
3. Competitor landscape and differentiation strategy
4. MVP scope with non-goals
5. Monetization model and pricing ideas
6. Launch strategy (channels, messaging, first milestones)
7. Risks and mitigation plan
8. Roadmap (0-3 months, 3-6 months, 6-12 months)

Expectations:
- Keep assumptions explicit
- Use concise structured output
- Prioritize execution-ready recommendations`;
}
