import type {
  AppSettings,
  GeneratorOptions,
  IdeaAnalysis,
} from "@/lib/prompt-engine/types";
import {
  buildContextBlock,
  languageRules,
  list,
  stylePresetGuidance,
} from "@/lib/prompt-engine/templates";

export function generateDesignPrompt(
  analysis: IdeaAnalysis,
  options: GeneratorOptions,
  settings: AppSettings,
) {
  return `Role:
You are a senior product designer generating production-grade UI specifications for ${options.targetTool}.

Project Context:
${buildContextBlock(options, analysis)}

Product Goal:
Convert the idea into a complete, visually coherent ${options.projectType} experience.

Target Users:
${analysis.targetUsers}

Main User Journey:
${list(analysis.suggestedScreens.slice(0, 4))}

Required Screens:
${list(analysis.suggestedScreens)}

Visual Style:
${stylePresetGuidance(options.stylePreset)}

Layout Requirements:
- Build clear section hierarchy with intentional whitespace
- Include empty, loading, and error states
- Preserve visual consistency across all screens
- Keep component density aligned with ${options.complexity}

Component Requirements:
${list(analysis.coreFeatures)}

Interaction Requirements:
- Define primary and secondary actions per screen
- Add transition behavior and interactive states
- Keep keyboard and focus accessibility

Responsiveness:
- Desktop, tablet, and mobile variants required
- Keep layout stability under long text and bilingual copy

Accessibility:
- Maintain readable contrast and focus indicators
- Support semantic structure and clear navigation landmarks

RTL Support:
${
  options.language !== "English"
    ? "- Apply full RTL-safe spacing, alignment, and typography where Arabic is used."
    : "- Maintain LTR layout."
}

Content Guidelines:
${languageRules(options.language)}

Things to Avoid:
- Generic boilerplate composition
- Inconsistent spacing and typography scales
- Decorative visual noise that harms readability

Final Output Expectations:
- Screen-by-screen design specification
- Component-level notes and variants
- Interaction summary
- Responsive and accessibility notes
${
  settings.compactOutput
    ? "- Keep response concise and implementation-oriented."
    : "- Include enough detail for direct implementation handoff."
}`;
}
