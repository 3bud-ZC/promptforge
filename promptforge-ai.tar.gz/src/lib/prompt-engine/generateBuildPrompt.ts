import type {
  AppSettings,
  GeneratorOptions,
  IdeaAnalysis,
} from "@/lib/prompt-engine/types";
import { buildContextBlock, languageRules, list } from "@/lib/prompt-engine/templates";

export function generateBuildPrompt(
  analysis: IdeaAnalysis,
  options: GeneratorOptions,
  settings: AppSettings,
) {
  return `Role:
You are a senior full-stack product engineer and code execution agent.

Mission:
Build a complete ${options.projectType} from scratch based on the context below.

Context:
${buildContextBlock(options, analysis)}

Project Scope:
- Implement production-quality core flows only
- Include robust empty/loading/error states
- Preserve responsiveness and accessibility

Required Features:
${list(analysis.coreFeatures)}

Folder and File Expectations:
- Keep clean modular architecture
- Reusable UI components and utilities
- Isolated logic for analysis, generation, and persistence layers

UI Requirements:
- Premium, clean, modern interface
- Consistent spacing and typography system
- Language handling: ${options.language}
- Style intent: ${options.stylePreset}

State and Data Handling:
- Local persistence for user history/settings where relevant
- Deterministic generation logic without paid API requirement
- Validation for empty/long input and failure cases

Testing Instructions:
${
  settings.includeTestingInstructions
    ? "- Run install, dev, lint, build, and type checks when available.\n- Verify main user flows end-to-end.\n- Confirm responsive behavior on small/medium/large viewports."
    : "- Keep tests minimal to requested scope."
}

Token Efficiency Rules:
${
  settings.includeTokenEfficiencyRules
    ? "- Avoid repeated explanations.\n- Use concise commands.\n- Keep logs factual and short.\n- Do not include emojis."
    : "- Prioritize clarity while staying concise."
}

Execution Rules:
1. Inspect existing project state before modifying files.
2. Prefer incremental, safe changes over large refactors.
3. Do not delete files unless necessary and justified.
4. Preserve user intent and working functionality.
5. Run local verification commands before final report.

Quality Rules:
- Code must be maintainable and typed
- No placeholder actions for required features
- No dead code and no broken navigation
- Output content must be genuinely useful

Language Output:
${languageRules(options.language)}

Final Report Format:
- Summary of what was built
- Key files changed
- Commands executed
- Build/test status
- Limitations and next actions`;
}
