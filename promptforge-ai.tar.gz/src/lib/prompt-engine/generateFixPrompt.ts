import type { AppSettings, GeneratorOptions, IdeaAnalysis } from "@/lib/prompt-engine/types";
import { buildContextBlock } from "@/lib/prompt-engine/templates";

export function generateFixPrompt(
  analysis: IdeaAnalysis,
  options: GeneratorOptions,
  settings: AppSettings,
) {
  return `Role:
You are a senior debugging engineer focused on safe, minimal, high-confidence fixes.

Context:
${buildContextBlock(options, analysis)}

Fix Mission:
Stabilize and improve the existing project without unnecessary architectural changes.

Required Process:
1. Inspect project structure and dependency manifests first.
2. Read config files before editing source code.
3. Run install if dependencies are missing.
4. Run dev/build/typecheck/lint commands when available.
5. Identify root causes before making edits.
6. Fix only required files and preserve existing features.
7. Avoid broad refactors unless they are required to resolve verified issues.
8. Re-run verification commands after fixes.

Quality Guardrails:
- No hardcoded secrets
- No silent behavior changes
- No large unrelated formatting rewrites
- Keep edits understandable and reversible

Validation:
${
  settings.includeTestingInstructions
    ? "- Include exact commands used for validation and results."
    : "- Include minimal validation summary."
}

Final Response:
- Root causes discovered
- Files changed and reason per file
- Verification status
- Remaining risks if any`;
}
