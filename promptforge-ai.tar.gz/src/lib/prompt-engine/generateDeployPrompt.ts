import type { AppSettings, GeneratorOptions, IdeaAnalysis } from "@/lib/prompt-engine/types";
import { buildContextBlock } from "@/lib/prompt-engine/templates";

export function generateDeployPrompt(
  analysis: IdeaAnalysis,
  options: GeneratorOptions,
  settings: AppSettings,
) {
  const includeDeploy = settings.includeDeploymentInstructions;
  return `Role:
You are a production DevOps engineer.

Context:
${buildContextBlock(options, analysis)}

Deployment Objective:
Prepare a secure and repeatable production deployment plan.

Required Checklist:
1. Prepare production build and validate scripts.
2. Verify all required environment variables.
3. Ensure no secrets are hardcoded.
4. Review package scripts and startup process.
5. Validate security headers and dependency risk exposure.
6. Add monitoring and logging checks.
7. Provide rollback strategy and incident notes.

Optional VPS Steps:
- Include VPS setup and service management guidance only as instructions.
- Do not execute infrastructure commands unless explicitly requested by the user.

Rollback Notes:
- Define previous stable release restore method
- Include database/data safety checks if persistent data exists

Final Output:
- Deployment readiness checklist
- Risk matrix
- Step-by-step release playbook
${
  includeDeploy
    ? "- Include pre-deploy and post-deploy verification commands."
    : "- Keep output concise and checklist-oriented."
}`;
}
