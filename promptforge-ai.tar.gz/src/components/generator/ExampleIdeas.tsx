import { EXAMPLE_IDEAS } from "@/data/examples";
import { Button } from "@/components/ui/Button";
import { useI18n } from "@/components/providers/I18nProvider";

export function ExampleIdeas({
  onPick,
}: {
  onPick: (idea: string) => void;
}) {
  const { locale } = useI18n();

  return (
    <div className="space-y-3">
      <p className="text-xs font-medium uppercase tracking-widest text-slate-400">
        {locale === "ar" ? "أفكار جاهزة" : "Example Ideas"}
      </p>
      <div className="grid gap-2 md:grid-cols-2">
        {EXAMPLE_IDEAS.map((example) => (
          <Button
            key={example.title}
            variant="outline"
            size="sm"
            className="justify-start text-start"
            onClick={() => onPick(example.idea)}
          >
            {locale === "ar" ? (example.titleAr ?? example.title) : example.title}
          </Button>
        ))}
      </div>
    </div>
  );
}
