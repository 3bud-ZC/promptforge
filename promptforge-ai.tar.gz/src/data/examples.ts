export const EXAMPLE_IDEAS = [
  {
    title: "Islamic Sunnah daily routine app",
    titleAr: "تطبيق روتين السنة اليومي",
    idea: "I want to build an Islamic app that helps people follow the Prophet's daily routine with authentic sources, reminders, progress tracking, and an AI assistant for practical daily questions.",
  },
  {
    title: "AI skincare consultant website",
    titleAr: "موقع مستشار عناية بالبشرة بالذكاء الاصطناعي",
    idea: "Build a premium AI skincare consultant site where users answer a skin quiz, upload photos, and receive routines, product suggestions, and follow-up plans.",
  },
  {
    title: "Inventory ERP dashboard",
    titleAr: "لوحة ERP للمخزون",
    idea: "Create an ERP dashboard for inventory and purchasing with role-based access, low-stock alerts, supplier tracking, and monthly performance reports.",
  },
  {
    title: "Birthday cinematic website",
    titleAr: "موقع سينمائي لعيد ميلاد",
    idea: "Design a cinematic birthday microsite with personalized story sections, photo timeline, background music controls, and mobile-first sharing.",
  },
  {
    title: "2D browser game",
    titleAr: "لعبة متصفح ثنائية الأبعاد",
    idea: "Build a 2D browser game with levels, collectibles, enemies, boss fights, and a progression system that saves user progress locally.",
  },
  {
    title: "Telegram automation bot",
    titleAr: "بوت أتمتة تيليجرام",
    idea: "Create a Telegram automation bot platform for scheduling posts, analyzing engagement, and managing multiple channels with templates.",
  },
  {
    title: "E-commerce Instagram catalog",
    titleAr: "كتالوج إنستجرام للتجارة الإلكترونية",
    idea: "Develop an e-commerce catalog app optimized for Instagram sellers with product cards, auto-generated captions, and WhatsApp checkout links.",
  },
  {
    title: "AI study planner",
    titleAr: "مخطط دراسة بالذكاء الاصطناعي",
    idea: "I need an AI study planner app that builds weekly plans based on exam dates, tracks progress, and suggests revision strategies for weak topics.",
  },
];
