import { analyzeIdea } from "@/lib/prompt-engine/analyzeIdea";
import { generateBuildPrompt } from "@/lib/prompt-engine/generateBuildPrompt";
import { generateBusinessPrompt } from "@/lib/prompt-engine/generateBusinessPrompt";
import { generateDeployPrompt } from "@/lib/prompt-engine/generateDeployPrompt";
import { generateDesignPrompt } from "@/lib/prompt-engine/generateDesignPrompt";
import { generateFixPrompt } from "@/lib/prompt-engine/generateFixPrompt";
import { scorePrompt } from "@/lib/prompt-engine/scorePrompt";
import type {
  AppSettings,
  GeneratedOutputs,
  GeneratorOptions,
} from "@/lib/prompt-engine/types";

export function generatePromptPackage(
  idea: string,
  options: GeneratorOptions,
  settings: AppSettings,
): GeneratedOutputs {
  const analysis = analyzeIdea(idea, options);

  const designPrompt = generateDesignPrompt(analysis, options, settings);
  const buildPrompt = generateBuildPrompt(analysis, options, settings);
  const fixPrompt = generateFixPrompt(analysis, options, settings);
  const deployPrompt = generateDeployPrompt(analysis, options, settings);
  const businessPrompt = generateBusinessPrompt(analysis, options);

  const mode = options.outputMode;
  const outputs = {
    analysis,
    designPrompt: mode === "design" || mode === "full" ? designPrompt : "",
    buildPrompt: mode === "build" || mode === "full" ? buildPrompt : "",
    fixPrompt: mode === "fix" || mode === "full" ? fixPrompt : "",
    deployPrompt: mode === "deploy" || mode === "full" ? deployPrompt : "",
    businessPrompt: mode === "business" || mode === "full" ? businessPrompt : "",
    qualityReport: scorePrompt(idea, analysis, options, {
      designPrompt,
      buildPrompt,
      fixPrompt,
      deployPrompt,
      businessPrompt,
    }),
  };

  return outputs;
}

export * from "@/lib/prompt-engine/types";
